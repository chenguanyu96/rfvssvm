# -*- coding: utf-8 -*-
import pandas as pd

def getdata(filename):
    return pd.read_csv(filename)

